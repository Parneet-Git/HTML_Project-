var ball=document.getElementById('ball');
    var left=0;
    var move=0;
    window.addEventListener("keydown",function(event){
        var kc=event.key;
        if(kc=="w"){
            move-=5;
            ball.style.top=move+"px";
        };
        if(kc=="a"){
            left-=5;
            ball.style.left=left+"px";
        };
        if(kc=="s"){
            move+=5;
            ball.style.top=move+"px";
        };
        if(kc=="d"){
            left+=5;
            ball.style.left=left+"px";
        };
    });