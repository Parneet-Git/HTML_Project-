var press=document.addEventListener("keydown",function(e){
				if(e.key==1){
					document.calc.text.value +='1';
				}
				if(e.key==2){
					document.calc.text.value +='2';
				}
				if(e.key==3){
					document.calc.text.value +='3';
				}
				if(e.key==4){
					document.calc.text.value +='4';
				}
				if(e.key==5){
					document.calc.text.value +='5';
				}
				if(e.key==6){
					document.calc.text.value +='6';
				}
				if(e.key==7){
					document.calc.text.value +='7';
				}
				if(e.key==8){
					document.calc.text.value +='8';
				}if(e.key==9){
					document.calc.text.value +='9';
				}
				if(e.key==0){
					document.calc.text.value +='0';
				}
				if(e.key=="+"){
					document.calc.text.value +='+';
				}
				if(e.key=="-"){
					document.calc.text.value +='-';
				}
				if(e.key=="*"){
					document.calc.text.value +='*';
				}
				if(e.key=="/"){
					document.calc.text.value +='/';
				}
				if(e.keyCode==13){
					document.calc.text.value=eval(calc.text.value);
				}

		});